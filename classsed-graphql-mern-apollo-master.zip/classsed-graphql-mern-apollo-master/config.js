module.exports = {
  MONGODB:
    'mongodb+srv://classsed:6lxxxlexaTslHLPe@cluster0-pcsru.mongodb.net/merng?retryWrites=true',
  SECRET_KEY: 'some very secret key'
};
